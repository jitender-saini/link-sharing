/**
 * Created by jitender on 3/3/17.
 */
import React from 'react';

export default class Footer extends React.Component {
  constructor(props) {
    super(props);
    }

render(){
  return (
    <div className="footer">Copyright &copy; To The New</div>
  );
}
}
