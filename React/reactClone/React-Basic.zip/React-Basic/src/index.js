/* eslint-disable no-console */
import React from 'react';
import {render} from 'react-dom';
import App from './App';
let app = document.getElementById('main');
render(<App />, app)
