package com.spring.demo;

public class ExpressTea implements HotDrink {

    @Override
    public void prepareHotDrink() {
        System.out.println("Preparing Express Tea");

    }
}
