package com.spring.demo;

public interface HotDrink {
    public abstract void prepareHotDrink();
}
