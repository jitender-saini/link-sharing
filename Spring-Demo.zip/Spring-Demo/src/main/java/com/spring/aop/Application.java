package com.spring.aop;

public class Application {
}
