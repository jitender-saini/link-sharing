package com.spring.AtmMachine.model.dao;

public class Otp {
    private int otp;

    public int getOtp() {
        return otp;
    }

    public Otp setOtp(int otp) {
        this.otp = otp;
        return this;
    }
}
